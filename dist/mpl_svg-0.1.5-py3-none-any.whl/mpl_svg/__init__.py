from .mpl_svg import svg_plot

__all__ = [svg_plot]